<?php
session_start();

$USN1 = $_POST['USN'];
$password = $_POST['PASSWORD'];
$confirm = $_POST['repassword'];

$mysqli = new mysqli("localhost", "root", "", "placement");

if ($mysqli->connect_error) {
    die("Connection failed: ". $mysqli->connect_error);
}

if($password == $confirm) {
    $stmt = $mysqli->prepare("UPDATE hlogin SET Password =? WHERE Username =?");
    $stmt->bind_param("ss", $password, $USN1);
    $stmt->execute();
    echo "<center>Password Reset Complete</center>";
    session_unset();
} else {
    echo "Update Failed";
}

$mysqli->close();
?>