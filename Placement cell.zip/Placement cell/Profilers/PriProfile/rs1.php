<?php
session_start();

$USN1 = $_POST['USN'];
$password = $_POST['PASSWORD'];
$confirm = $_POST['repassword'];

$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if ($password == $confirm) {
    $sql = "UPDATE prilogin SET PASSWORD = '$password' WHERE prilogin.Username = '$USN1'";
    if ($connect->query($sql) === TRUE) {
        echo "<center>Password Reset Complete</center>";
        echo "<center> <a href='index.php'>Go Back</a></center>";
    } else {
        echo "Error updating record: " . $connect->error;
    }
    session_unset();
} else {
    echo "Update Failed";
}
?>