<?php
$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if (isset($_POST['submit'])) {
    $Name = $_POST['Fullname'];
    $USN = $_POST['USN'];
    $password = $_POST['PASSWORD'];
    $repassword = $_POST['repassword'];
    $Email = $_POST['Email'];
    $Question = $_POST['Question'];
    $Answer = $_POST['Answer'];

    if ($USN!= '' && $Email!= '') {
        if ($repassword == $password) {
            $check = "SELECT * FROM slogin WHERE USN=?";
            $stmt = $connect->prepare($check);
            $stmt->bind_param("s", $USN);
            $stmt->execute();
            $result = $stmt->get_result();
            $num_rows = $result->num_rows;

            if ($num_rows == 0) {
                $query = "INSERT INTO slogin(Name, USN,PASSWORD,Email,Question,Answer) VALUES (?,?,?,?,?,?)";
                $stmt = $connect->prepare($query);
                $stmt->bind_param("ssssss", $Name, $USN, $password, $Email, $Question, $Answer);

                if ($stmt->execute()) {
                    echo "<center> You have registered successfully...!! Go back to  </center>";
                    echo "<center><a href='index.php'>Login here</a> </center>";
                } else {
                    echo "FAILED";
                }

                $stmt->close();
            } else {
                echo "<center>This USN already exists</center>";
            }
        } else {
            echo "<center>Your password do not match</center>";
        }
    }
}

$connect->close();
?>