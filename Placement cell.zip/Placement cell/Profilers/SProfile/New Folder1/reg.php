<?php
$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if (isset($_POST['submit'])) {
    $Name = $_POST['Fullname'];
    $USN = $_POST['USN'];
    $password = $_POST['PASSWORD'];
    $repassword = $_POST['repassword'];
    $Email = $_POST['Email'];
    $Question = $_POST['Question'];
    $Answer = $_POST['Answer'];

    if ($repassword == $password) {
        $check = $connect->query("SELECT * FROM slogin WHERE USN='$USN'") or die("Check Query");
        if ($check->num_rows == 0) {
            $query = "INSERT INTO slogin(Name, USN,PASSWORD,Email,Question,Answer) VALUES ('$Name', '$USN', '$password','$Email','$Question','$Answer')";

            if ($connect->query($query) === TRUE) {
                echo "<center> You have registered successfully...!! Go back to  </center>";
                echo "<center><a href='index.php'>Login here</a> </center>";
            } else {
                echo "<center>Failed! Try Again</center>";
            }
        } else {
            echo "<center>This USN already exists</center>";
        }
    } else {
        echo "<center>Password do not match</center>";
    }
}
?>