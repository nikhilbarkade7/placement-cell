<?php
session_start();

$USN1 = $_POST['USN'];
$password = $_POST['PASSWORD'];
$confirm = $_POST['repassword'];
$USN2 = ($_SESSION['reset']);

$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if ($USN1 && $password && $confirm) {
    if ($password == $confirm) {
        if ($USN2 == $USN1) {
            $stmt = $connect->prepare("UPDATE `slogin` SET `PASSWORD` = ? WHERE `slogin`.`USN` = ?");
            $stmt->bind_param("ss", $password, $USN1);
            $stmt->execute();
            echo "<center>Password Reset Complete</center>";
            session_unset();
        } else {
            session_unset();
            die("Enter Your USN only");
        }
    } else {
        echo "Update Failed";
        session_unset();
    }
} else {
    echo "Field cannot be left blank";
    session_unset();
}

$connect->close();
?>