<?php
session_start();
$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

$Username = $_SESSION['username'];
$Password = $_POST['Password'];
$repassword = $_POST['repassword'];
$cur = $_POST['curpassword'];
if ($Password && $repassword && $cur) {
    if ($Password == $repassword) {
        $sql = "SELECT * FROM slogin WHERE USN='$Username'";
        $result = $connect->query($sql);
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $dbpassword = $row['PASSWORD'];

            if ($cur == $dbpassword) {
                if ($query = $connect->query("UPDATE slogin SET PASSWORD = '$Password' WHERE slogin.USN = '$Username'")) {
                    echo "<center>Password Changed Successfully</center>";
                } else {
                    echo "<center>Can't Be Changed! Try Again</center>";
                }
            } else {
                die("<center>Error! Please Check ur Password</center>");
            }
        } else {
            die("<center>Username not Found</center>");
        }
    } else {
        die("<center>Passwords Donot Match</center>");
    }
} else {
    die ("<center>Enter All Fields</center>");
}
?>