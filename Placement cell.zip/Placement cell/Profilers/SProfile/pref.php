<?php
  session_start();
  if($_SESSION["username"]){
    echo "Welcome, ".$_SESSION['username']."!";
  }
   else {
	   header("location: index.php");
}
   
?>
<?php
// Establishing Connection with Server
$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['Fname'];
    $lname = $_POST['Lname'];
    $USN = $_POST['USN'];
    $sun = $_SESSION["username"];
    $phno = $_POST['Num'];
    $email = $_POST['Email'];
    $date = $_POST['DOB'];
    $cursem = $_POST['Cursem'];
    $branch = $_POST['Branch'];
    $per = $_POST['Percentage'];
    $puagg = $_POST['Puagg'];
    $beaggregate = $_POST['Beagg'];
    $back = $_POST['Backlogs'];
    $hisofbk = $_POST['History'];
    $detyear = $_POST['Dety'];

    if ($USN!= '' || $email!= '') {
        if ($USN == $sun) {
            $query = "INSERT INTO `basicdetails` (`FirstName`, `LastName`, `USN`, `Mobile`, `Email`, `DOB`, `Sem`, `Branch`, `SSLC`, `PU/Dip`, `BE`, `Backlogs`, `HofBacklogs`, `DetainYears`, `Approve`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            if ($stmt = $connect->prepare($query)) {
                // Create variables with the same name as the parameters and assign them values
                $fname_var = $fname;
                $lname_var = $lname;
                $usn_var = $USN;
                $phno_var = $phno;
                $email_var = $email;
                $date_var = $date;
                $cursem_var = $cursem;
                $branch_var = $branch;
                $per_var = $per;
                $puagg_var = $puagg;
                $beaggregate_var = $beaggregate;
                $back_var = $back;
                $hisofbk_var = $hisofbk;
                $detyear_var = $detyear;
                $approve_var = 0;

                // Use the variables in bind_param instead of the parameters directly
                $stmt->bind_param("sssssssssssssss", $fname_var, $lname_var, $usn_var, $phno_var, $email_var, $date_var, $cursem_var, $branch_var, $per_var, $puagg_var, $beaggregate_var, $back_var, $hisofbk_var, $detyear_var, $approve_var);

                if ($stmt->execute()) {
                    echo "<center>Details has been received successfully...!!</center>";
                } else {
                    echo "FAILED";
                }

                $stmt->close();
            }
        } else {
            echo "<center>enter your USN only...!!</center>";
        }
    }
}

$connect->close();
?>
<?php
// Establishing Connection with Server
$connect = new mysqli("localhost", "root", "", "placement");

if ($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if (isset($_POST['update'])) {
    $fname = $_POST['Fname'];
    $lname = $_POST['Lname'];
    $USN = $_POST['USN'];
    $sun = $_SESSION["username"];
    $phno = $_POST['Num'];
    $email = $_POST['Email'];
    $date = $_POST['DOB'];
    $cursem = $_POST['Cursem'];
    $branch = $_POST['Branch'];
    $per = $_POST['Percentage'];
    $puagg = $_POST['Puagg'];
    $beaggregate = $_POST['Beagg'];
    $back = $_POST['Backlogs'];
    $hisofbk = $_POST['History'];
    $detyear = $_POST['Dety'];

    if ($USN!= '' || $email!= '') {
        if ($USN == $sun) {
            $query = "SELECT * FROM `basicdetails` WHERE `USN` =?";
            $stmt = $connect->prepare($query);
            $stmt->bind_param("s", $USN);
            $stmt->execute();
            $result = $stmt->get_result();
            $num_rows = $result->num_rows;

            if ($num_rows == 1) {
                $query = "UPDATE `basicdetails` SET `FirstName` =?, `LastName` =?, `Mobile` =?, `Email` =?, `DOB` =?, `Sem` =?, `Branch` =?, `SSLC` =?, `PU/Dip` =?, `BE` =?, `Backlogs` =?, `HofBacklogs` =?, `DetainYears` =?, `Approve` = '0' WHERE `USN` =?";
                $stmt = $connect->prepare($query);
                $stmt->bind_param("ssssssssssssss", $fname, $lname, $phno, $email, $date, $cursem, $branch, $per, $puagg, $beaggregate, $back, $hisofbk, $detyear, $USN);

                if ($stmt->execute()) {
                    echo "<center>Data Updated successfully...!!</center>";
                } else {
                    echo "<center>FAILED</center>";
                }

                $stmt->close();
            } else {
                echo "<center>NO record found for update</center>";
            }
        } else {
            echo "<center>enter your usn only</center>";
        }
    }
}

$connect->close();
?>