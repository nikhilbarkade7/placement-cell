<?php
session_start();

$USN1 = $_POST['USN'];
$password = $_POST['PASSWORD'];
$confirm = $_POST['repassword'];

$connect = new mysqli("localhost", "root", "", "placement"); // Establishing Connection with Server
if($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if($password == $confirm) {
    if($sql = $connect->query("UPDATE `placement`.`plogin` SET `Password` ='$password' WHERE `plogin`.`Username` = '$USN1'")) {
        echo "<center>Password Reset Complete</center>";
        session_unset();
    } else {
        echo "Update Failed";
    }
}
?>