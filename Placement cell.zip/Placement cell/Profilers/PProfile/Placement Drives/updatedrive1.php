<?php
$connect = new mysqli("localhost", "root", "", "placement"); // Establishing Connection with Server

if(isset($_POST['submit']))
{ 
    $usn = $_POST['usn'];
    $name = $_POST['sname'];
    $comname = $_POST['comname'];
    $date = $_POST['Date'];
    $attend = $_POST['Attendance'];
    $wt = $_POST['WrittenTest'];
    $gd = $_POST['GD'];
    $tech = $_POST['Tech'];
    $placed = $_POST['Placed'];

    // Check if the CompanyName and Date exist in the addpdrive table
    $check_query = "SELECT * FROM addpdrive WHERE CompanyName =? AND Date =?";
    $stmt = $connect->prepare($check_query);
    $stmt->bind_param("ss", $comname, $date);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // The CompanyName and Date exist in the addpdrive table, so insert the data into the updatedrive table
        $query = "INSERT INTO updatedrive(USN, Name, CompanyName, Date, Attendence, WT, GD, Techical, Placed)
        VALUES('$usn', '$name', '$comname', '$date', '$attend', '$wt', '$gd', '$tech', '$placed')";

        if ($connect->query($query)) {
            echo "<center>Data Inserted successfully...!!</center>";
        } else {
            echo "<center>FAILED</center>";
        }
    } else {
        echo "<center>The CompanyName and Date do not exist in the addpdrive table</center>";
    }
}

$connect->close();
?>