<?php
$connect = new mysqli("localhost", "root", "", "placement"); // Establishing Connection with Server
if($connect->connect_error) {
    die("Connection failed: ". $connect->connect_error);
}

if(isset($_POST['update']))
{ 
$Username = $_POST['Fname'];
$Password = $_POST['Lname'];
$Email = $_POST['USN'];
$Question = $_SESSION["username"];
$Answer = $_POST['Num'];


if($USN!=''||$email!='')
{
	if($USN == $sun)
	{
		
	$sql = "SELECT * FROM `details`.`basicdetails` WHERE `USN`='$USN'";
	$result = $connect->query($sql);
	if($result->num_rows == 1)
	{
  
		if($query = $connect->query("UPDATE `details`.`basicdetails` SET `FirstName`='$fname', `LastName`='$lname', `Mobile`='$phno', `Email`='$email', `DOB`='$date', `Sem`='$cursem', `Branch`= '$branch', `SSLC`='$per', `PU/Dip`='$puagg', `BE`='$beaggregate', `Backlogs`='$back', `HofBacklogs`='$hisofbk', `DetainYears`='$detyear',`Approve`='0'
           WHERE `basicdetails`.`USN` = '$USN'"))
               {
				echo "<center>Data Updated successfully...!!</center>";
               }
	  
            else echo "<center>FAILED</center>";
		
	}	
	else echo "<center>NO record found for update</center>";
	}
else
	echo "<center>enter your usn only</center>";
}
}
?>